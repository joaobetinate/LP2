﻿namespace atividade7
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.texto = new System.Windows.Forms.RichTextBox();
            this.contador = new System.Windows.Forms.Button();
            this.posicao = new System.Windows.Forms.Button();
            this.letras = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // texto
            // 
            this.texto.Location = new System.Drawing.Point(29, 52);
            this.texto.Name = "texto";
            this.texto.Size = new System.Drawing.Size(432, 87);
            this.texto.TabIndex = 0;
            this.texto.Text = "";
            // 
            // contador
            // 
            this.contador.Location = new System.Drawing.Point(47, 254);
            this.contador.Name = "contador";
            this.contador.Size = new System.Drawing.Size(140, 71);
            this.contador.TabIndex = 1;
            this.contador.Text = "Contador";
            this.contador.UseVisualStyleBackColor = true;
            this.contador.Click += new System.EventHandler(this.Button1_Click);
            // 
            // posicao
            // 
            this.posicao.Location = new System.Drawing.Point(309, 254);
            this.posicao.Name = "posicao";
            this.posicao.Size = new System.Drawing.Size(140, 71);
            this.posicao.TabIndex = 2;
            this.posicao.Text = "Branco";
            this.posicao.UseVisualStyleBackColor = true;
            this.posicao.Click += new System.EventHandler(this.Posicao_Click);
            // 
            // letras
            // 
            this.letras.Location = new System.Drawing.Point(577, 254);
            this.letras.Name = "letras";
            this.letras.Size = new System.Drawing.Size(140, 71);
            this.letras.TabIndex = 3;
            this.letras.Text = "Letras";
            this.letras.UseVisualStyleBackColor = true;
            this.letras.Click += new System.EventHandler(this.Letras_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Texto:";
            this.label1.Click += new System.EventHandler(this.Label1_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.letras);
            this.Controls.Add(this.posicao);
            this.Controls.Add(this.contador);
            this.Controls.Add(this.texto);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox texto;
        private System.Windows.Forms.Button contador;
        private System.Windows.Forms.Button posicao;
        private System.Windows.Forms.Button letras;
        private System.Windows.Forms.Label label1;
    }
}