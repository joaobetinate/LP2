﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atividade7
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void Remover_Click(object sender, EventArgs e)
        {
            int posicao = palavra2.Text.IndexOf(palavra1.Text,
               StringComparison.OrdinalIgnoreCase);

            //a        a        ss
            //casa    Fatec    assessoria
            //c       F        a

            while (posicao >= 0)
            {
                palavra2.Text = palavra2.Text.Substring(0, posicao) +
                    palavra2.Text.Substring(posicao + palavra1.Text.Length,
                    palavra2.Text.Length - posicao - palavra1.Text.Length);

                posicao = palavra2.Text.IndexOf(palavra1.Text,
               StringComparison.OrdinalIgnoreCase);
            }
        }

        private void Remover2_Click(object sender, EventArgs e)
        {
            palavra1.Text = palavra1.Text.ToUpper();
            palavra2.Text = palavra2.Text.ToUpper();
            palavra2.Text = palavra2.Text.Replace(palavra1.Text, "");
        }

        private void Inverter3_Click(object sender, EventArgs e)
        {
            char[] vetorC = palavra1.Text.ToCharArray();

            Array.Reverse(vetorC);
            palavra2.Text = "";

            foreach (char C in vetorC)
            palavra2.Text += C;


        }
    }
    }

 