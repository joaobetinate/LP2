﻿namespace atividade7
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inverter3 = new System.Windows.Forms.Button();
            this.remover2 = new System.Windows.Forms.Button();
            this.remover = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.palavra2 = new System.Windows.Forms.TextBox();
            this.palavra1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // inverter3
            // 
            this.inverter3.Location = new System.Drawing.Point(421, 217);
            this.inverter3.Name = "inverter3";
            this.inverter3.Size = new System.Drawing.Size(106, 64);
            this.inverter3.TabIndex = 13;
            this.inverter3.Text = "Inverter";
            this.inverter3.UseVisualStyleBackColor = true;
            this.inverter3.Click += new System.EventHandler(this.Inverter3_Click);
            // 
            // remover2
            // 
            this.remover2.Location = new System.Drawing.Point(240, 217);
            this.remover2.Name = "remover2";
            this.remover2.Size = new System.Drawing.Size(112, 64);
            this.remover2.TabIndex = 12;
            this.remover2.Text = "Remover 2";
            this.remover2.UseVisualStyleBackColor = true;
            this.remover2.Click += new System.EventHandler(this.Remover2_Click);
            // 
            // remover
            // 
            this.remover.Location = new System.Drawing.Point(57, 217);
            this.remover.Name = "remover";
            this.remover.Size = new System.Drawing.Size(114, 64);
            this.remover.TabIndex = 11;
            this.remover.Text = "Remover";
            this.remover.UseVisualStyleBackColor = true;
            this.remover.Click += new System.EventHandler(this.Remover_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "Palavra 2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "Palavra 1:";
            // 
            // palavra2
            // 
            this.palavra2.Location = new System.Drawing.Point(115, 98);
            this.palavra2.Name = "palavra2";
            this.palavra2.Size = new System.Drawing.Size(280, 26);
            this.palavra2.TabIndex = 8;
            // 
            // palavra1
            // 
            this.palavra1.Location = new System.Drawing.Point(112, 33);
            this.palavra1.Name = "palavra1";
            this.palavra1.Size = new System.Drawing.Size(280, 26);
            this.palavra1.TabIndex = 7;
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.inverter3);
            this.Controls.Add(this.remover2);
            this.Controls.Add(this.remover);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.palavra2);
            this.Controls.Add(this.palavra1);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button inverter3;
        private System.Windows.Forms.Button remover2;
        private System.Windows.Forms.Button remover;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox palavra2;
        private System.Windows.Forms.TextBox palavra1;
    }
}