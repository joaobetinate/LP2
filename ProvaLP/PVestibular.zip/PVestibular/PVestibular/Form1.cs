﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVestibular
{
    public partial class Form1 : Form
    {
        int[,] matrizPVestibular = new int[2, 4];
        int[] vetorTotalPorCurso = new int[4];
        int totalGeral = 0;
        int totalAnos = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    string entrada = Interaction.InputBox("Digite a quantidade de alunos do curso " + (i + 1) + " do ano " + (j + 1) + ":");
                    matrizPVestibular[i, j] = int.Parse(entrada);
                    vetorTotalPorCurso[i] += matrizPVestibular[i, j];
                    totalGeral += matrizPVestibular[i, j];
                    
                   
                    listBox1.Items.Add("Total do Curso " + (i + 1) + " Ano " + (j + 1) + " " + matrizPVestibular[i, j]);
                   

                }
                listBox1.Items.Add("*Total Curso " + vetorTotalPorCurso[i]);
                listBox1.Items.Add("--------------------------");
                
            }
            totalAnos += totalGeral;
            listBox1.Items.Add("*Total Anos: " + totalAnos);
        }

        private void ListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
             listBox1.Items.Clear();
        }
    }
}
